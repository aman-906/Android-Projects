package com.example.simplecalculator;

import static com.example.simplecalculator.R.id.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import javax.crypto.Mac;

public class MainActivity extends AppCompatActivity {
     Button buttonAdd, buttonSub, buttonMul, buttonDiv;
    EditText editTextN1, editTextN2;
    TextView textview;

    int num1, num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buttonAdd = (Button) findViewById(btn_add);
        buttonSub = (Button) findViewById(R.id.btn_sub);
        buttonMul = (Button) findViewById(R.id.btn_mul);
        buttonDiv = (Button) findViewById(R.id.btn_div);
        editTextN1 = (EditText) findViewById(R.id.number1);
        editTextN2 = (EditText) findViewById(R.id.number2);
        textview = (TextView) findViewById(answer);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editTextN1.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num1 = Integer.parseInt(editTextN1.getText().toString());
                }

                if (editTextN2.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num2 = Integer.parseInt(editTextN2.getText().toString());
                }
                textview.setText("Answer = " + (num1 + num2));

            }
        });
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editTextN1.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num1 = Integer.parseInt(editTextN1.getText().toString());
                }

                if (editTextN2.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num2 = Integer.parseInt(editTextN2.getText().toString());
                }
                textview.setText("Answer = " + (num1 - num2));
            }
        });
        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editTextN1.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num1 = Integer.parseInt(editTextN1.getText().toString());
                }

                if (editTextN2.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num2 = Integer.parseInt(editTextN2.getText().toString());
                }
                textview.setText("Answer = " + (num1 * num2));
            }
        });
        buttonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editTextN1.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num1 = Integer.parseInt(editTextN1.getText().toString());
                }

                if (editTextN2.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter number", Toast.LENGTH_SHORT).show();
                } else {
                    num2 = Integer.parseInt(editTextN2.getText().toString());
                }
                textview.setText("Answer = " + ((float) num1 / (float) num2));
            }
        });
    }
 }