package com.andr.flashit;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button OnFlash, OffFlash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        OnFlash = findViewById(R.id.flashOn);
        OffFlash = findViewById(R.id.flashOff);

        OnFlash.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    flashOnMethod();
                }
            }
        });


        OffFlash.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                flashOffMethod();
            };
        });
    }
    @SuppressLint("NewApi")
    @RequiresApi(api= Build.VERSION_CODES.LOLLIPOP)
    public void flashOnMethod() {
        CameraManager cameraManager = null;
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        String cameraId = null;

                try {
                    cameraId = cameraManager.getCameraIdList()[0];
                } catch (CameraAccessException e) {

            e.printStackTrace();
        }
        try {
            cameraManager.setTorchMode(cameraId, true);
        } catch (CameraAccessException e) {

            e.printStackTrace();
        }
    }
        @SuppressLint("NewApi")
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public void flashOffMethod () {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;
            try {
                cameraId = cameraManager.getCameraIdList()[0];
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
            try {
                cameraManager.setTorchMode(cameraId, false);
            } catch (CameraAccessException e) {

                e.printStackTrace();
            }


        }
    }